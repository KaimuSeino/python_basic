from kaimu_package.tools import utils

def sing():
  return "sing sahfodaskfnoasndfjnosan"

def cry():
  return utils.say_twice("skfoaskdfosfbjkaowneig!!!!!!!!1")