# from kaimu_package.tools import utils

from ..tools import utils # あんまりいい書き方ではないよーー

def sing():
  return "sing"

def cry():
  return utils.say_twice("cry")